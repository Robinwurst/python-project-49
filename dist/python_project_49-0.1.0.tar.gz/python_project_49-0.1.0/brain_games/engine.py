from modules.game_modules import *


def engine(true_answer, user_answer):
    """Движок для игр. Принимает аргументы: true_answer, user_answer, question"""
    welcome()
    while answer_check(user_answer, true_answer):
        score_check(answer_check)
    else:
        return
