import prompt
import random


def welcome():
    print(f'Welcome to the Brain Games!\nMay I have your name?')
    user_name = prompt.string(prompt=None, empty=False)
    print(f'Hello, {user_name}!')


def even_odd():
    hidden_number = random.randint(0, 1000)
    print(f'Answer "yes" if the number is even, otherwise answer "no".')
    print(f'Question: {hidden_number}')
    answer = prompt.integer(prompt=None, empty=False)
    print(f'Your answer: {answer}')
    if answer % 2 == 0:
        print('Correct!')
    else:
        print(f"'yes' is wrong answer ;(. Correct answer was 'no'.")
