from brain_games.engine import engine
from brain_games.games.calc_game import game_func

user_answer, true_answer, question = game_func


def main():
    engine(user_answer, true_answer)


if __name__ == '__main__':
    main()
